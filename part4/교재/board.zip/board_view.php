<?php
$host = 'localhost'; // MySQL 호스트
$username = 'dietmall'; // MySQL 사용자명
$password = '1111'; // MySQL 비밀번호
$database = 'dietmall'; // 사용할 데이터베이스명
//$board_idx=1;

$board_idx=$_GET['board_idx'];
$conn = mysqli_connect($host, $username, $password, $database);
mysqli_set_charset($conn, "utf8");
$query = "SELECT * FROM board2 where board_idx=".$board_idx;
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset='utf-8'>
</head>
<body>
<h3>문의 게시판 읽기</h3>
<form action="board_write_ok.php" method="post">
<table>
    <tr>
        <td>이름</td><td><?php echo $row['write_name']; ?> </td>
    </tr>
    <tr>
        <td>제목</td><td><input type='text'></td>
    </tr>
    <tr>
        <td>내용</td><td><textarea rows='6' cols='50'></textarea></td>
    </tr>
    <tr>
	    <td colspan='2'><input type="submit" value="확인"></td>
    </tr>
</table>
</form>
</body>
</html>